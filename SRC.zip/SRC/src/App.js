import React,{ Component } from 'react';
import Todo from './todos';
import AddTodo from './AddTodos';

class App extends Component {
  state = {
    todo:[
      {id: 1, content: "Do homework"},
      {id: 2, content: "Dance"}
    ]
  }
  deleteTodo=(id)=>{
    let todo=this.state.todo.filter(todo=>{
      return todo.id !== id;
    })
    this.setState({
      todo
    })
  }
  addTodo = (todos) => {
    todos.id = Math.random();
    let todo = [...this.state.todo,todos]
    this.setState({
      todo
    })
  }
  render(){
    return(
        <div className="todo-app container">
          <h1 className="center blue-text">Todo's</h1>
          <Todo todos={this.state.todo} deleteTodo={this.deleteTodo}/>
          <AddTodo addTodo={this.addTodo}/>
        </div>
    );
  }
}

export default App;
